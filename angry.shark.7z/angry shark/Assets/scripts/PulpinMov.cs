﻿using UnityEngine;
using System.Collections;

public class PulpinMov : MonoBehaviour {

    float deltaMovement = 1f;
    float bajar=0;
    float adelante = 0;
    void Start () {
        
    }
	
	
	void Update () {

        if (Input.GetKey(KeyCode.W))
        {
            bajar = bajar + 2;
            adelante = adelante + 5;
            transform.Translate(Vector2.right * adelante * Time.deltaTime);
            transform.Translate(Vector2.up * bajar * Time.deltaTime);
            bajar = bajar - 2;
            adelante = adelante - 5;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            bajar = bajar + 2;
            adelante = adelante + 5;
            transform.Translate(Vector2.right * adelante * Time.deltaTime);
            transform.Translate(Vector2.down * bajar * Time.deltaTime);
            bajar = bajar - 2;
            adelante = adelante - 5;
        }
        else
        {
            
            transform.Translate(Vector2.down * deltaMovement * Time.deltaTime);
        }
    }
    
   
    
}
