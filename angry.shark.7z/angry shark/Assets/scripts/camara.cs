﻿using UnityEngine;
using System.Collections;

public class camara : MonoBehaviour {


    float adelante = 2f;


    void Update () {
        transform.Translate(Vector2.right * adelante * Time.deltaTime);
    }
    


    
    

    
}
